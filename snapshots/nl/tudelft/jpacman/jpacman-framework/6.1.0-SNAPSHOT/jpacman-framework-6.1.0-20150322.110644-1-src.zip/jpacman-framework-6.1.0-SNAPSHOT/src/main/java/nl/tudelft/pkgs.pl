#!/usr/bin/perl 

use strict;
use warnings;

# print "digraph jpacman {\n";

my $line;
LINE: foreach $line (<>) {
  # print $line;

#  if ($line =~ /\.\/([\w\.\/]+)\/([A-Z]\w+)\.java:import nl.tudelft.jpacman\.([\w\.]+)\.([A-Z]\w+)/) {
  if ($line =~ /\.\/([\w\.\/]+)\/([A-Z]\w+)\.java:import nl.tudelft\.([\w\.]+)\.([A-Z]\w+)/) {
    my $p1 = $1;
    my $c1 = $2;
    my $p2 = $3;
    $p1 =~ s/\//\./g;
    print "\"$p1\" -> \"$p2\" \n";

    
  }
}

# print "}\n";
